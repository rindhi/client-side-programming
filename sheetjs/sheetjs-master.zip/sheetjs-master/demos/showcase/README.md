# Showcase

Many use cases are too complex to summarize in a short demo.  The listed open
source projects use SheetJS libraries in clever deployments.

### vscode-data-preview

**Deployment**: Visual Studio Code Extension

**Website**: <https://marketplace.visualstudio.com/items?itemName=RandomFractalsInc.vscode-data-preview>

**Repository**: <https://github.com/RandomFractals/vscode-data-preview>

**Notes**: Demonstrates reading and writing files.
